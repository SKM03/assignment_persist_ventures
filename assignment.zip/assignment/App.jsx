import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomeScreen from './features/home/presentation/HomeScreen'; // Home Page
import VotingScreen from './features/voting/presentation/VotingScreen'; // Voting Page
import Navbar from './common/components/Navbar'; // Navigation bar

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomeScreen />} /> {/* Home Route */}
        <Route path="/voting" element={<VotingScreen />} /> {/* Voting Route */}
      </Routes>
    </Router>
  );
};

export default App;
