import React, { useEffect, useState } from 'react';
import { fetchHomeData } from '../data/homeApi'; // API Function

const HomeScreen = () => {
  const [data, setData] = useState([]); // State for API data
  const [loading, setLoading] = useState(true); // Loading state

  useEffect(() => {
    const loadData = async () => {
      try {
        const result = await fetchHomeData(); // Fetch data
        setData(result);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false); // Stop loading
      }
    };

    loadData(); // Call the fetch function
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Home Feed</h1>
      <ul>
        {data.map((item) => (
          <li key={item.id}>{item.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default HomeScreen;
