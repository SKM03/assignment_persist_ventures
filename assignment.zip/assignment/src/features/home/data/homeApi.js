import { apiClient } from '../../../common/utils/apiClient'; // Shared Axios Client

export const fetchHomeData = async () => {
  try {
    const response = await apiClient.get('/home'); // API Endpoint for Home
    return response.data;
  } catch (error) {
    console.error('Error fetching home data:', error);
    throw error;
  }
};
