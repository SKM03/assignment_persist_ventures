export const getHomeData = async (apiClient) => {
    try {
      const response = await apiClient.get('/home');
      return response.data;
    } catch (error) {
      console.error('Error fetching home data:', error);
      throw error;
    }
  };
  