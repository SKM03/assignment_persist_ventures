export const submitVote = async (apiClient, voteData) => {
    try {
      const response = await apiClient.post('/vote', voteData);
      return response.data;
    } catch (error) {
      console.error('Error submitting vote:', error);
      throw error;
    }
  };
  