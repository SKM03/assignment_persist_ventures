import { apiClient } from '../../../common/utils/apiClient'; // Shared Axios Client

export const postVote = async (voteData) => {
  try {
    const response = await apiClient.post('/vote', voteData); // API Endpoint for Voting
    return response.data;
  } catch (error) {
    console.error('Error submitting vote:', error);
    throw error;
  }
};
