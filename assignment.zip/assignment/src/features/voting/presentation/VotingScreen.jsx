import React, { useState } from 'react';
import { postVote } from '../data/votingApi'; // API Function

const VotingScreen = () => {
  const [vote, setVote] = useState(''); // Selected vote state
  const [message, setMessage] = useState(''); // Success/Error message

  const handleSubmit = async () => {
    try {
      const response = await postVote({ vote }); // Submit vote
      setMessage('Vote submitted successfully!');
    } catch (error) {
      setMessage('Error submitting vote.');
      console.error(error);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Voting Screen</h1>
      <select
        onChange={(e) => setVote(e.target.value)}
        value={vote}
        className="p-2 border"
      >
        <option value="">Select an option</option>
        <option value="option1">Option 1</option>
        <option value="option2">Option 2</option>
      </select>
      <button
        onClick={handleSubmit}
        className="bg-blue-500 text-white px-4 py-2 mt-2"
      >
        Submit Vote
      </button>
      {message && <p>{message}</p>} {/* Show feedback message */}
    </div>
  );
};

export default VotingScreen;
