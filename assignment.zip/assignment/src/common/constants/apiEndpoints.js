export const API_ENDPOINTS = {
    HOME: '/home',
    VOTE: '/vote',
  };
  