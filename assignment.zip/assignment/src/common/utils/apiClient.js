import axios from 'axios';

export const apiClient = axios.create({
  baseURL: 'https://api.example.com', // Replace with your actual API URL
  headers: {
    'Content-Type': 'application/json',
  },
});
